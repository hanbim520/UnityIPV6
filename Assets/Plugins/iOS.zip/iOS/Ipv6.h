@interface BundleId : NSObject
+(NSString *)getIPv6 : (const char *)host;
+(NSString*) getIPv6 : (const char*)mHost :(const char*)mPort;
@end
